var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'gabecampbell',
applicationName: 'notes-app-api-app',
appUid: 'srdsJkhFcttmRgl1hc',
tenantUid: 'xFHSKpGnR8yKVHqZ9Y',
deploymentUid: 'ea96fe34-d153-48a5-935c-ba624919248f',
serviceName: 'notes-app-api',
stageName: 'prod',
pluginVersion: '3.1.2'})
const handlerWrapperArgs = { functionName: 'notes-app-api-prod-get', timeout: 6}
try {
  const userHandler = require('./get.js')
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
