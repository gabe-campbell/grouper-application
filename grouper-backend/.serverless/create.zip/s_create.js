var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'gabecampbell',
applicationName: 'notes-app-api-app',
appUid: 'srdsJkhFcttmRgl1hc',
tenantUid: 'xFHSKpGnR8yKVHqZ9Y',
deploymentUid: '712b1f71-6d1b-405a-bc37-c62032e92bf0',
serviceName: 'notes-app-api',
stageName: 'dev',
pluginVersion: '3.2.4'})
const handlerWrapperArgs = { functionName: 'notes-app-api-dev-create', timeout: 6}
try {
  const userHandler = require('./create.js')
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
