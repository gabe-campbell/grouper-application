var serverlessSDK = require('./serverless_sdk/index.js')
serverlessSDK = new serverlessSDK({
tenantId: 'gabecampbell',
applicationName: 'notes-app-api-app',
appUid: 'srdsJkhFcttmRgl1hc',
tenantUid: 'xFHSKpGnR8yKVHqZ9Y',
deploymentUid: 'f81cbb5d-f88f-44da-946e-737d78e537f5',
serviceName: 'notes-app-api',
stageName: 'dev',
pluginVersion: '3.1.2'})
const handlerWrapperArgs = { functionName: 'notes-app-api-dev-billing', timeout: 6}
try {
  const userHandler = require('./billing.js')
  module.exports.handler = serverlessSDK.handler(userHandler.main, handlerWrapperArgs)
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs)
}
